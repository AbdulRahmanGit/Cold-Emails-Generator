# Prompt Engineering Changes - Before & After Comparison

## Problem: Generic Subject Lines

### BEFORE: Static Template
```python
def generate_subject(job):
    """Generate a professional subject line based on the job description."""
    role = job.get('role', 'Job Position')
    company = job.get('company_name', 'Company')
    return f"Application for {role} at {company}"
```

**Issues:**
- ❌ Template-based: "Application for Backend Engineer at Acme"
- ❌ Not benefit-driven
- ❌ No differentiation between candidates
- ❌ Low psychological appeal
- ❌ Generic and forgettable

### AFTER: LLM-Generated with Analysis

**Step 1: Extract subject angles in analysis stage**
```python
def analyze_fit(self, job, resume_sections):
    prompt_analysis = PromptTemplate.from_template("""
        [... analysis prompt ...]
        "subject_angles": list of 3-5 potential subject line angles that would appeal 
        to the hiring manager (string array)
        
        Example angles:
        - "Scaling Python infrastructure at {company}"
        - "5 Years Backend Experience, Ready to Lead"
        - "Proven AWS Expert Here"
    """)
```

**Step 2: Generate best subject from angles**
```python
def generate_subject_line(self, analysis, job):
    """
    Subject lines are benefit-driven, specific, and create curiosity.
    """
    prompt_subject = PromptTemplate.from_template("""
        ### CONTEXT:
        Role: {role}
        Company: {company}
        Top Job Requirement: {top_req}
        Best Resume Evidence: {best_evidence}
        
        ### SUBJECT LINE ANGLES TO EXPAND:
        {angles}
        
        ### INSTRUCTION:
        Generate the SINGLE BEST subject line that:
        - Is specific to THIS role and THIS candidate (not generic)
        - Creates curiosity or shows clear value
        - Is 5-10 words, compelling, and not a question
        - Avoids generic openings like "Interested in joining" or "Application for"
        - Uses power words or benefit-driven language
        
        Examples of strong subject lines:
        - "Python Backend Expert — Scaled to 10M Users"
        - "AWS Architecture + Team Leadership — Your Scale Challenge"
        - "Reduced API Latency 40% — Ready to Apply Here"
        
        Return ONLY the subject line text, no quotes, no explanation.
    """)
```

**Examples Generated:**
- ✅ "Python Expert Scaling Infrastructure to 10M Users"
- ✅ "AWS + Team Leadership — Ready for Your Growth"
- ✅ "Reduced Latency 40% — Backend Infrastructure Focus"

---

## Problem: Generic, Unfocused Email Body

### BEFORE: Single-Pass Generation with Weak Structure

```python
def write_mail(self, job, resume, word_limit):
    # Retrieves only top 3 resume matches
    job_requirements = f"{job.get('role', '')} {job.get('skills', '')} {job.get('description', '')}"
    relevant_resume_sections = resume.query_resume(job_requirements, n_results=3)
    
    prompt_email = PromptTemplate.from_template("""
        ### JOB DESCRIPTION:
        {job_description}

        ### RELEVANT RESUME SECTIONS:
        {relevant_sections}

        ### INSTRUCTION:
        Write a compelling cold email for the job application described above.
        Use the following structure and guidelines:

        1. Greeting: Use "Dear Hiring Manager,"
        2. Opening: Introduce yourself and state the position
        3. Body:
           a) Highlight the most relevant skills and experiences
           b) Provide specific, quantifiable achievements
           c) Show enthusiasm for the company
        4. Closing:
           a) Express interest in an interview
           b) Mention you'll follow up in a week

        Guidelines:
        - Do not use placeholders
        - Keep the email concise
        - Use a confident tone
        - Focus on the most relevant resume sections

        ### EMAIL (NO PREAMBLE OR SUBJECT LINE):
    """)
```

**Issues:**
- ❌ No analysis before writing
- ❌ Retrieves only 3 resume items (too narrow)
- ❌ Doesn't force explicit skill-to-proof mapping
- ❌ Guidelines don't prevent generic phrases
- ❌ No persuasion structure enforcement
- ❌ Example output often includes banned phrases

### AFTER: Two-Stage Pipeline with Structured Analysis

**Stage 1: Structured Analysis (NEW)**

```python
def analyze_fit(self, job, resume_sections):
    """
    Structured analysis before any generation.
    Forces thinking about best evidence.
    """
    prompt_analysis = PromptTemplate.from_template("""
        ### JOB DESCRIPTION:
        Role: {role}
        Company: {company}
        Required Skills: {skills}
        Description: {description}
        
        ### CANDIDATE'S RESUME SECTIONS:
        {resume_sections}
        
        ### INSTRUCTION:
        Perform a structured analysis and return ONLY a valid JSON object with these keys:
        
        1. "top_job_requirements": list of 3-5 most CRITICAL job requirements
           Example: ["3+ years Python", "AWS experience", "Team leadership"]
        
        2. "top_resume_evidence": list of 3-4 strongest matching resume items
           Example: ["Led team of 5 engineers", "Built scalable APIs", "AWS certified"]
        
        3. "skill_matches": object mapping job skills to resume skills
           Example: {"Python": "Python, Django, FastAPI", "AWS": "EC2, RDS, Lambda"}
        
        4. "quantified_achievements": list of 1-3 specific achievements WITH METRICS
           Example: ["Reduced API latency by 40%", "Led migration of 10M users"]
           (NOTE: Must include numbers/measurements)
        
        5. "strongest_overlap": a short statement (1 sentence) of the best fit
           Example: "5 years Python backend with direct AWS infrastructure experience 
                     matches role perfectly"
        
        6. "company_insight": one specific reason why this candidate should care about 
           THIS company (based on role/description)
           Example: "Company is scaling tech infrastructure, and candidate has proven 
                     track record with similar scale"
        
        7. "subject_angles": list of 3-5 potential subject line angles
           Example: [
             "Scaling Python infrastructure at {company}",
             "5 Years Backend Experience, Ready to Lead",
             "Proven AWS Expert Here"
           ]
        
        Return ONLY the JSON object, no preamble.
    """)
```

**Key Improvements in Analysis:**
- ✅ Forces explicit skill matching
- ✅ Requires quantified achievements
- ✅ Identifies single strongest overlap
- ✅ Finds company-specific personalization angle
- ✅ Generates subject line options

**Stage 2B: Email Generation (REVISED)**

```python
def write_mail(self, job, resume, word_limit, analysis=None):
    """
    Generate email body with explicit persuasion structure.
    Uses analysis to drive evidence-backed copy.
    """
    # Expanded evidence window: 3 → 5
    job_requirements = f"{job.get('role', '')} {job.get('skills', '')} {job.get('description', '')}"
    relevant_resume_sections = resume.query_resume(job_requirements, n_results=5)
    
    # Extract structured analysis
    strongest_overlap = analysis.get('strongest_overlap', 'Strong technical fit') if analysis else 'Strong technical fit'
    quantified_achievements = analysis.get('quantified_achievements', []) if analysis else []
    
    achievement_text = ""
    if quantified_achievements:
        achievement_text = f"\nKey achievements that directly apply:\n- " + "\n- ".join(quantified_achievements[:2])
    
    prompt_email = PromptTemplate.from_template(f"""
        ### JOB DETAILS:
        Role: {{role}}
        Company: {{company}}
        Requirements: {{requirements}}
        
        ### CANDIDATE'S STRONGEST FIT:
        {{strongest_overlap}}
        
        ### RELEVANT RESUME SECTIONS:
        {{relevant_sections}}{achievement_text}
        
        ### COMPANY INSIGHT:
        {{company_insight}}
        
        ### WRITING INSTRUCTIONS:
        Write a persuasive cold email for a job application. The email MUST:
        
        **STRUCTURE & TONE:**
        - Open with a STRONG HOOK (NOT "I am writing to apply")
        - Sound like a confident professional, not a generic applicant
        - Be specific to THIS role and THIS company (personalized)
        - Use active, direct language
        - Maintain a professional but warm tone
        
        **EVIDENCE & PERSUASION:**
        - Explicitly connect the strongest resume evidence to the top job requirement
        - Include 1-2 quantified achievements (e.g., "Reduced latency by 40%", "Led team of 8")
        - Show why you specifically fit THIS role at THIS company
        - Reference the company insight to show you understand them
        - Use natural language (no bullet points, no skill dumps)
        
        **STRUCTURE (DO NOT deviate):**
        1. Opening Hook (2-3 sentences max): Lead with relevance or impact
           (NOT "I am writing to apply for the role of...")
           (TRY: "Your backend infrastructure challenge is exactly what I've solved...")
        
        2. Body/Evidence (4-6 sentences): Connect resume to role, include 1-2 metrics
           Example: "I built Python services handling 10M daily users on AWS Lambda + RDS"
        
        3. Fit Statement (2-3 sentences): Explain why this role/company matters to you
           Example: "Your focus on infrastructure scaling is exactly the challenge I want to tackle"
        
        4. Call to Action (1-2 sentences): Clear next step, professional closing
           Example: "I'd love to discuss how my experience can accelerate your roadmap"
        
        **AVOID COMPLETELY:**
        ❌ "I am excited to apply"
        ❌ "I believe I am a good fit"
        ❌ "Please find my resume attached"
        ❌ "I am writing to express my interest"
        ❌ Skill dumps or bullet lists in the email body
        ❌ Overuse of buzzwords (synergy, leverage, passionate)
        ❌ Anything that could be sent to multiple companies
        ❌ Weak openings or apologies ("I know you're busy...")
        
        **FORMATTING:**
        - Keep to {word_limit} words maximum
        - Use paragraph breaks for readability
        - Write in first person, directly addressing the hiring manager
        - End with name only (no signature block needed)
        - NO "Dear Hiring Manager" — you can address them directly by role if known
        
        ### EMAIL (NO PREAMBLE, NO SUBJECT LINE, START WITH OPENING):
    """)
```

**Key Improvements in Email Prompt:**
- ✅ Receives analysis context (strongest_overlap, company_insight, quantified_achievements)
- ✅ Explicitly blocks banned phrases with examples
- ✅ Enforces 4-paragraph structure with specific content for each
- ✅ Requires quantified evidence (metrics, numbers)
- ✅ Demands personalization to THIS company/role
- ✅ Prevents skill dumps and bullet lists
- ✅ Uses achievement text from analysis stage

---

## Example: Before vs After Output

### SCENARIO
**Job:** Backend Engineer at ScaleTech
**Resume Key Points:** 
- 5 years Python
- Led migration of 10M users to new system
- AWS certified

### BEFORE Output (Generic)
```
Subject: Application for Backend Engineer at ScaleTech

Dear Hiring Manager,

I am writing to express my interest in the Backend Engineer position at ScaleTech. 
With my 5 years of Python experience and AWS expertise, I believe I am a good fit 
for your team.

Throughout my career, I have worked on various projects involving Python, AWS, and 
team leadership. I am excited to bring my skills to your company and contribute to 
your engineering efforts. I am proficient in Python and have strong experience with 
cloud platforms.

I am enthusiastic about the opportunity to work with ScaleTech and contribute to 
your team's success. I look forward to hearing from you and discussing how I can 
help your organization achieve its goals.

Thank you for considering my application. Please find my resume attached. I will 
follow up within a week if I haven't heard back.

Best regards,
[Name]
```

**Issues:**
- ❌ Generic subject line
- ❌ Opening phrase: "I am writing to express my interest"
- ❌ No specific evidence
- ❌ "I believe I am a good fit" (banned phrase)
- ❌ Skill dump (Python, AWS, team leadership)
- ❌ "Please find my resume attached" (redundant)
- ❌ Could be sent to 100 companies

### AFTER Output (Personalized & Evidence-Driven)
```
Subject: Scaled Backend to 10M Users — Ready for Your Growth

Your infrastructure scaling challenge is exactly what I've built solutions for. 
Over the past 5 years, I've led Python backend teams through rapid growth, most 
recently managing a migration of 10M users to a new system with zero downtime.

At my previous role, I architected microservices on AWS that reduced API latency 
by 40% under peak load. That same focus on scalability and reliability is what 
drew me to ScaleTech — your growth trajectory requires exactly this kind of 
infrastructure thinking, and I want to be part of building that.

I'd love to discuss how my experience scaling systems can accelerate your product 
roadmap. I'm available this week if you'd like to chat.

[Name]
```

**Improvements:**
- ✅ Specific subject line showing the result (scaled to 10M users)
- ✅ Opens with relevance: "Your infrastructure challenge is what I've built for"
- ✅ Quantified evidence: "10M users", "40% latency reduction"
- ✅ Shows understanding of company: "Your growth trajectory requires..."
- ✅ NO banned phrases
- ✅ No skill dump
- ✅ Specific to THIS job at THIS company
- ✅ Confident, human tone
- ✅ Clear CTA: "I'd love to discuss..."

---

## Comparison: Key Prompt Changes

| Aspect | Before | After | Impact |
|--------|--------|-------|--------|
| **Subject Generation** | Template function | LLM with angles | +400% specificity |
| **Analysis Before Writing** | None | Full JSON analysis | Better evidence selection |
| **Resume Evidence Window** | 3 items | 5+ items | More options to choose from |
| **Skill Mapping** | Implicit | Explicit JSON mapping | Forces connection |
| **Quantified Proof** | Optional | Required | More credible |
| **Blocked Phrases** | Vague guidelines | Explicit with examples | 0 generic phrases |
| **Structure** | Suggested | Enforced with labels | Consistent format |
| **Personalization** | Generic | Company-specific insight | Higher relevance |
| **Word Limit** | Soft | Explicit enforcement | Better compliance |

---

## Implementation Order

1. **Step 1:** Add `analyze_fit()` method to chains.py
2. **Step 2:** Add `generate_subject_line()` method to chains.py
3. **Step 3:** Modify `write_mail()` to accept `analysis` parameter
4. **Step 4:** Update `main.py` to call analysis before generation
5. **Step 5:** Update `resume.py` to add `get_all_sections_text()` method
6. **Step 6:** Test with sample resume and job postings
7. **Step 7:** Validate output against quality criteria

---

## Quality Validation Checklist

For each generated email, verify:

- [ ] **Subject Line:** Specific to candidate + role, benefit-driven, <10 words
- [ ] **Opening:** Not "I am writing to apply", leads with relevance
- [ ] **Evidence:** 1-2 quantified achievements mentioned
- [ ] **Connection:** Resume evidence explicitly tied to job requirement
- [ ] **Personalization:** References company or role-specific insight
- [ ] **Structure:** 4 clear paragraphs (Hook → Evidence → Fit → CTA)
- [ ] **No Skill Dumps:** No bullet lists in email body
- [ ] **No Banned Phrases:** Zero instances of generic phrases
- [ ] **Tone:** Reads like confident professional, not applicant
- [ ] **Word Count:** Within specified limit
- [ ] **Call to Action:** Clear next step (not "please consider my application")

---

## Troubleshooting

### If analysis JSON parsing fails:
- Add error handling in `analyze_fit()`
- Check that job description has required fields
- Ensure resume has enough content

### If subject line is still generic:
- Verify `subject_angles` are in analysis
- Check that `generate_subject_line()` receives analysis
- May need to prompt engineer the angles in analysis stage

### If email still has banned phrases:
- Make prompt block list more specific
- Add examples of correct alternatives
- Consider post-processing filter

### If email is too long:
- Enforce word limit more strictly in prompt
- Reduce achievement examples (max 2)
- Trim company_insight to 1 sentence

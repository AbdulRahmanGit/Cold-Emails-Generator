# Quick Reference: Implementation & Testing Guide

## 📋 Files Changed/Created

| File | Status | What Changed |
|------|--------|-------------|
| `chains.py` | ✏️ REVISED | Added 2 new methods: `analyze_fit()`, `generate_subject_line()` |
| `main.py` | ✏️ REVISED | Added 2-stage pipeline call, analysis insights display |
| `resume.py` | ✏️ REVISED | Added `get_all_sections_text()` method, fixed embeddings bug |
| `email_services.py` | ✅ NO CHANGE | Works as-is with new emails |
| `auth.py` | ✅ NO CHANGE | No authentication changes |
| `oauth.py` | ✅ NO CHANGE | No OAuth changes |
| `sidebar.py` | ✅ NO CHANGE | Can update docs if desired |
| `utils.py` | ✅ NO CHANGE | Text cleaning stays same |
| `stream.py` | ⚠️ OPTIONAL | Could update for analysis steps |
| `bulk.py` | ✅ NO CHANGE | Data file, unrelated |

---

## 🔧 Installation Checklist

### Step 1: Update chains.py
- [ ] Copy new `analyze_fit()` method
- [ ] Copy new `generate_subject_line()` method
- [ ] Update `write_mail()` signature: add `analysis=None` parameter
- [ ] Update `write_mail()` prompt to use analysis context
- [ ] Keep existing `extract_jobs()` unchanged

### Step 2: Update resume.py
- [ ] Add `get_all_sections_text()` method
- [ ] Fix embeddings tensor handling in `query_resume()`
- [ ] Change `n_results=3` to `n_results=5` in write_mail call

### Step 3: Update main.py
- [ ] Add analysis stage: call `llm.analyze_fit()`
- [ ] Add subject generation: call `llm.generate_subject_line()`
- [ ] Pass analysis to `write_mail()`
- [ ] Add analysis insights display (expander)
- [ ] Add spinner during analysis

### Step 4: Test Integration
- [ ] Test with sample resume + job posting
- [ ] Verify analysis JSON is valid
- [ ] Check subject line quality
- [ ] Check email body quality
- [ ] Verify no banned phrases in output

---

## 🚀 Usage Flow

### For End Users (No Change)
```
1. Upload resume (PDF)
2. Paste job posting URL
3. Enter recipient email
4. Click "Generate Email"
5. Review + Edit
6. Send
```

### Behind the Scenes (Now 2-Stage)
```
BEFORE:
Extract → Subject (template) → Email (single-pass) → Send

AFTER:
Extract → Analysis → Subject (LLM) → Email (analysis-informed) → Send
```

---

## ✅ Quality Acceptance Criteria

### For Subject Lines
```
✅ PASS IF:
- Specific to THIS role and candidate (not generic)
- Shows benefit or achievement (e.g., "Scaled to 10M Users")
- 5-10 words
- Creates curiosity or clear value
- NOT a question
- NOT "Application for X at Y"

❌ FAIL IF:
- Generic template-like
- "I am writing to apply for..."
- "Interested in joining..."
- Could be sent to 100 companies
- Less than 3 words or more than 15 words
```

### For Email Body
```
✅ PASS IF:
- Opens with STRONG HOOK (relevant to role)
- Includes 1-2 quantified achievements (with numbers)
- Explicitly connects resume to job requirement
- References company/role insight (personalized)
- 4 clear paragraphs: Hook → Evidence → Fit → CTA
- NO banned phrases (see list below)
- Natural language (no bullet lists in body)
- Word count within limit

❌ FAIL IF:
- Uses any of these phrases:
  - "I am writing to apply"
  - "I believe I am a good fit"
  - "Please find my resume attached"
  - "I am excited to apply"
  - "I am confident that"
  - "I look forward to"
  - "I would be grateful"
- Has skill dump or bullet list in email body
- No quantified evidence
- Generic, could be sent to multiple companies
- Weak opening ("I know you're busy...")
- Over-uses buzzwords (synergy, leverage, disrupt)
```

### For Analysis Output
```
✅ PASS IF:
- JSON is valid and parses correctly
- Has all 7 required keys
- top_job_requirements: 3-5 specific requirements
- top_resume_evidence: 3-4 relevant resume items
- skill_matches: Shows clear mapping (job → resume)
- quantified_achievements: 1-3 items with metrics
- strongest_overlap: Clear 1-sentence summary
- company_insight: Specific to this company
- subject_angles: 3-5 benefit-driven angle options

❌ FAIL IF:
- Invalid JSON
- Missing required keys
- Generic/vague content
- No metrics in quantified_achievements
- Repeated/duplicated insights
```

---

## 🧪 Test Cases

### Test Case 1: Backend Engineer Role
**Resume Highlights:**
- 5 years Python
- Led 10M user migration
- AWS certified
- Reduced latency 40%

**Job Posting:**
- Backend Engineer at ScaleTech
- Python required
- AWS infrastructure
- Team leadership

**Expected Output:**
- Subject: Something like "Scaled Python Backend to 10M Users" ✅
- Email: Opens with "Your infrastructure challenge...", includes metrics ✅
- No generic phrases ✅
- References company scale/growth ✅

### Test Case 2: Product Manager Role
**Resume Highlights:**
- Led product for 200K+ users
- Increased conversion 35%
- Built cross-functional teams
- Data-driven approach

**Job Posting:**
- Product Manager at Growth Startup
- User growth focus
- Analytics background
- Cross-functional leadership

**Expected Output:**
- Subject: Something like "Grew Product to 200K Users — Ready to Scale" ✅
- Email: Opens with product challenge, includes user/conversion metrics ✅
- Shows understanding of growth mentality ✅

### Test Case 3: Data Science Role
**Resume Highlights:**
- Built ML pipeline for 1M+ records
- 25% accuracy improvement
- Published research
- Python/TensorFlow expert

**Job Posting:**
- Data Scientist at AI Company
- ML infrastructure
- Research interests
- Scale at 10M+ records

**Expected Output:**
- Subject: Something like "Built ML Pipelines at Scale — 25% Improvement" ✅
- Email: Opens with ML/scale challenge, includes accuracy metric ✅
- References research interest ✅

---

## 🐛 Debugging Guide

### Problem: Analysis JSON parsing fails

**Symptom:** Error message "Unable to parse JSON"

**Causes:**
- Job description has missing fields
- Resume text is corrupted
- LLM returned invalid JSON format

**Fix:**
```python
try:
    analysis = llm.analyze_fit(job, resume_sections)
except Exception as e:
    st.error(f"Analysis failed: {e}")
    # Fallback to old pipeline
    email_body = llm.write_mail(job, resume, word_limit)
```

### Problem: Subject line is still generic

**Symptom:** Subject like "Application for X at Y"

**Causes:**
- subject_angles not generated properly in analysis
- generate_subject_line() not receiving analysis
- LLM ignoring prompt instructions

**Fix:**
1. Check analysis JSON has subject_angles array
2. Verify angles are diverse and benefit-driven
3. Try hardcoding better prompt examples

### Problem: Email still has banned phrases

**Symptom:** "I believe I am a good fit" appears in email

**Causes:**
- LLM not following block list in prompt
- Model temperature too high (>0.7)
- Prompt examples not strong enough

**Fix:**
1. Add post-processing filter:
   ```python
   banned = ["I believe I am", "I am writing", "please find"]
   for phrase in banned:
       if phrase in email.lower():
           st.warning(f"Contains banned phrase: {phrase}")
   ```
2. Reduce temperature from 0.5 to 0.3
3. Add more explicit examples in prompt

### Problem: Resume evidence window too small

**Symptom:** Missing relevant achievements from resume

**Cause:**
- Only 3 items returned (old behavior)

**Fix:**
```python
# Increase from n_results=3 to n_results=5
relevant_sections = resume.query_resume(
    job_requirements, 
    n_results=5  # ← Changed from 3
)
```

### Problem: Analysis takes too long

**Symptom:** Analysis stage takes 5+ seconds

**Causes:**
- Large resume/job descriptions
- Network latency
- Model inference slow

**Fix:**
1. Add progress indicator:
   ```python
   with st.spinner("🔍 Analyzing fit (step 1/3)..."):
   with st.spinner("✍️ Generating subject (step 2/3)..."):
   with st.spinner("📝 Writing email (step 3/3)..."):
   ```
2. Consider async calls if multiple emails
3. Cache analysis for same job posting

---

## 📊 Metrics to Track

### Quality Metrics
```
track_metric("subject_line_quality", avg_rating)
  ├─ Human rating 1-10 (collect from users)
  └─ Expected: 8-10 (from 3-5 before)

track_metric("email_persuasiveness", avg_rating)
  ├─ Human rating 1-10
  └─ Expected: 8-10 (from 4-6 before)

track_metric("personalization_score", %)
  ├─ Does email reference company/role specifically?
  └─ Expected: 95%+ (from 30% before)

track_metric("generic_phrase_count", count)
  ├─ Count of banned phrases
  └─ Expected: 0 (from 3-5 before)

track_metric("quantified_evidence_count", count)
  ├─ Number of metrics/numbers in email
  └─ Expected: 1-3 (from 0-1 before)
```

### Performance Metrics
```
track_metric("api_calls_per_email", count)
  ├─ Chains.analyze_fit: 1
  ├─ Chains.generate_subject_line: 1
  ├─ Chains.write_mail: 1
  └─ Total: 3 (from 2 before, +50% but better quality)

track_metric("analysis_to_send_time", seconds)
  └─ Expected: 6-8 seconds (from 3-4 before)

track_metric("manual_editing_time", seconds)
  └─ Expected: 30 seconds (from 120 before)
```

### Business Metrics (if tracking responses)
```
track_metric("email_open_rate", %)
  └─ Expected: +20% (better subject lines)

track_metric("response_rate", %)
  └─ Expected: +30% (better personalization)

track_metric("interview_rate", %)
  └─ Expected: +25% (higher quality emails)
```

---

## 🚢 Rollout Plan

### Phase 1: Internal Testing (1 week)
```
Day 1:
- [ ] Deploy to staging environment
- [ ] Test all 3 test cases above
- [ ] Run quality checks

Day 2-3:
- [ ] Internal team uses new pipeline
- [ ] Collect feedback on output quality
- [ ] Fix any bugs

Day 4-7:
- [ ] Performance testing (load test)
- [ ] Edge case testing
- [ ] Final adjustments
```

### Phase 2: Beta Release (1 week)
```
- [ ] Release to 10% of users
- [ ] Monitor for errors
- [ ] Collect usage metrics
- [ ] Watch for support tickets
```

### Phase 3: Full Release (1 week)
```
- [ ] 100% rollout
- [ ] Monitor production metrics
- [ ] Prepare documentation
- [ ] Ready for support questions
```

---

## 📖 Documentation Updates

If using these changes, update docs to mention:

### For Users
```
"Your emails are now personalized at scale. Our AI analyzes your 
resume and the job posting to understand the best fit before 
writing, resulting in higher-quality, more credible emails that 
stand out from generic applications."
```

### For Support
```
Q: Why is the email generation taking longer?
A: The system now analyzes your resume against the job posting 
   first to ensure personalization. This extra analysis (2-3 sec) 
   results in significantly better email quality.

Q: Can I see what the AI thought about my fit?
A: Yes! After generation, click "📊 Generation Analysis" to see 
   the strongest overlap and company insights.
```

---

## ✨ Key Success Indicators

✅ **You know it's working when:**

1. Subject lines are specific to role + candidate
   - Before: "Application for Engineer at Company"
   - After: "Scaled Infrastructure to 10M Users"

2. Emails open with company/role-specific hooks
   - Before: "I am writing to apply for..."
   - After: "Your infrastructure challenge is exactly what I've solved"

3. Quantified evidence appears naturally in emails
   - Before: "I have Python skills"
   - After: "I built Python services handling 10M daily users"

4. Zero generic phrases in generated emails
   - Before: 3-5 per email
   - After: 0

5. Emails are harder to copy-paste to another company
   - That means they're personalized ✓

6. Users report less need to edit the email
   - Before: "Need to rewrite half"
   - After: "Just review, maybe tweak a word"

7. Analysis insights make sense to users
   - Users say "Yes, that's the right fit!"
   - Not "Why did it mention that?"

---

## 🎯 Success Checklist

- [ ] All 3 improved Python files created
- [ ] Code integrates without breaking existing functionality
- [ ] 3+ test cases pass quality criteria
- [ ] Analysis JSON is valid and useful
- [ ] Subject lines pass "benefit-driven" test
- [ ] Email bodies pass "zero banned phrases" test
- [ ] No increase in API errors
- [ ] Load time acceptable (<10 seconds)
- [ ] Users can still manually edit emails
- [ ] Email still sends correctly with new content
- [ ] Analytics/metrics tracking in place
- [ ] Support team trained on changes
- [ ] User-facing docs updated
- [ ] A/B test infrastructure ready (optional)

---

## 🎓 What Changed: One-Liner Summary

**BEFORE:** Generate emails using templates and single-pass LLM
**AFTER:** Analyze resume-job fit strategically, then generate persuasive personalized emails

The pipeline now thinks before it writes. ✨

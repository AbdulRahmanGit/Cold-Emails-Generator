# Architecture & Flow Diagrams: Before vs After

## BEFORE: Single-Pass Generation Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│                     User Inputs                                  │
│  • URL (job posting) • Resume (PDF) • Recipient Email            │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────┐
        │   Extract Job Data       │
        │   from Careers Page      │
        └──────────────┬───────────┘
                       │
                       ▼
        ┌──────────────────────────┐
        │   Load Resume            │
        │   Parse PDF              │
        └──────────────┬───────────┘
                       │
                       ▼
        ┌──────────────────────────┐
        │  Subject Generation      │
        │  (Template-based)        │
        │                          │
        │ f"Application for        │
        │  {role} at {company}"    │
        └──────────────┬───────────┘
                       │
                       ▼
        ┌──────────────────────────┐
        │  Email Generation        │
        │  (Single-pass LLM)       │
        │                          │
        │  Input: Job + Resume     │
        │  Output: Email body      │
        │  (Generic, often weak)   │
        └──────────────┬───────────┘
                       │
                       ▼
        ┌──────────────────────────┐
        │  Format & Display        │
        │  Show to user for        │
        │  manual editing          │
        └──────────────┬───────────┘
                       │
                       ▼
            ┌────────────────────┐
            │  Send Email        │
            │  (if permitted)    │
            └────────────────────┘

PROBLEMS:
❌ No analysis before generation
❌ Subject is weak and generic
❌ Email lacks structure
❌ Only 3 resume items used
❌ No proof-of-fit mapping
❌ Often contains banned phrases
❌ Could be sent to many companies
```

---

## AFTER: Two-Stage Analysis + Generation Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│                     User Inputs                                  │
│  • URL (job posting) • Resume (PDF) • Recipient Email            │
└──────────────────────┬──────────────────────────────────────────┘
                       │
                       ▼
        ┌──────────────────────────┐
        │   Extract Job Data       │
        │   from Careers Page      │
        └──────────────┬───────────┘
                       │
                       ▼
        ┌──────────────────────────┐
        │   Load Resume            │
        │   Parse PDF              │
        │   Get Full Sections Text │
        └──────────────┬───────────┘
                       │
        ╔══════════════════════════╗
        ║  STAGE 1: ANALYSIS       ║ ◄─── NEW
        ╚══════════════════════════╝
                       │
                       ▼
        ┌──────────────────────────────────┐
        │  LLM: analyze_fit()              │
        │                                  │
        │  Input:                          │
        │  • Job role, skills, description │
        │  • Full resume sections          │
        │                                  │
        │  Output (JSON):                  │
        │  ✓ top_job_requirements (3-5)    │
        │  ✓ top_resume_evidence (3-4)     │
        │  ✓ skill_matches (object)        │
        │  ✓ quantified_achievements       │
        │  ✓ strongest_overlap (1 sentence)│
        │  ✓ company_insight               │
        │  ✓ subject_angles (3-5)          │
        └──────────────┬───────────────────┘
                       │
        ╔══════════════════════════╗
        ║  STAGE 2A: SUBJECT       ║ ◄─── IMPROVED
        ╚══════════════════════════╝
                       │
                       ▼
        ┌──────────────────────────────────┐
        │  LLM: generate_subject_line()    │
        │                                  │
        │  Input:                          │
        │  • Role, company                 │
        │  • Best resume evidence          │
        │  • subject_angles from analysis  │
        │                                  │
        │  Output:                         │
        │  Benefit-driven, specific,       │
        │  curiosity-creating subject      │
        │                                  │
        │  Example output:                 │
        │  "Scaled Backend to 10M Users" ✓ │
        │  NOT: "Application for Backend" ❌│
        └──────────────┬───────────────────┘
                       │
        ╔══════════════════════════╗
        ║  STAGE 2B: EMAIL BODY    ║ ◄─── IMPROVED
        ╚══════════════════════════╝
                       │
                       ▼
        ┌──────────────────────────────────┐
        │  LLM: write_mail()               │
        │  (Now with analysis context)     │
        │                                  │
        │  Input:                          │
        │  • Job details                   │
        │  • Resume (5+ items, not 3)      │
        │  • Analysis results ◄─── KEY!    │
        │    - strongest_overlap           │
        │    - quantified_achievements     │
        │    - company_insight             │
        │                                  │
        │  Enforced in prompt:             │
        │  ✓ Strong hook (NOT generic)     │
        │  ✓ 4-paragraph structure         │
        │  ✓ Skill-to-proof mapping        │
        │  ✓ 1-2 quantified metrics        │
        │  ✓ Company-specific personalization
        │  ✓ Clear CTA                     │
        │  ✓ NO banned phrases             │
        │  ✓ NO skill dumps or bullets     │
        │                                  │
        │  Output:                         │
        │  High-signal, personalized,      │
        │  evidence-backed email           │
        └──────────────┬───────────────────┘
                       │
                       ▼
        ┌──────────────────────────┐
        │  Format & Display        │
        │  Show to user for        │
        │  optional editing        │
        │  (Quality↑ so less       │
        │   editing needed)        │
        └──────────────┬───────────┘
                       │
                       ▼
            ┌────────────────────┐
            │  Send Email        │
            │  (if permitted)    │
            └────────────────────┘

IMPROVEMENTS:
✅ Analysis provides strategic context
✅ Subject is LLM-generated, benefit-driven
✅ Email has forced structure and persuasion
✅ 5+ resume items available to choose from
✅ Explicit skill-to-proof mapping
✅ 0 banned phrases (blocked in prompt)
✅ Highly personalized to job + company
✅ Higher quality = less manual editing needed
```

---

## Data Flow: Analysis Stage Details

```
                    STAGE 1: ANALYSIS
        ╔═════════════════════════════════╗
        ║  Input: Job + Full Resume       ║
        ╚═════════════════════════════════╝
                           │
              ┌────────────┴────────────┐
              │                         │
              ▼                         ▼
        Job Data:                Resume Data:
        • Role                   • Experience
        • Company                • Skills
        • Skills Required        • Education
        • Description            • Projects
                                 • Certifications
              │                         │
              └────────────┬────────────┘
                           │
                           ▼
        ┌──────────────────────────────┐
        │  LLM Structured Analysis     │
        │  (Forced JSON output)        │
        └──────────────┬───────────────┘
                       │
          ┌────────────┼────────────┐
          │            │            │
          ▼            ▼            ▼
    ┌─────────┐  ┌─────────┐  ┌──────────┐
    │ Extract │  │ Match   │  │ Identify │
    │ Top Job │  │ Skills: │  │ Company  │
    │ Reqs    │  │ Job→CV  │  │ Insight  │
    │         │  │         │  │          │
    │ 3-5 key │  │ Shows   │  │ Why THIS │
    │ items   │  │ clear   │  │ company? │
    │         │  │ mapping │  │          │
    └────┬────┘  └────┬────┘  └────┬─────┘
         │             │            │
         └─────────────┼────────────┘
                       │
          ┌────────────┼─────────────────┐
          │            │                 │
          ▼            ▼                 ▼
    ┌──────────┐ ┌──────────┐  ┌────────────┐
    │ Extract  │ │ Generate │  │ Create     │
    │ Quant.   │ │ Strongest│  │ Subject    │
    │ Achieve. │ │ Overlap  │  │ Angles     │
    │          │ │ Statement│  │            │
    │ 1-3 with │ │          │  │ 3-5        │
    │ metrics  │ │ 1 sent.  │  │ angles     │
    │          │ │ of best  │  │            │
    │ "Led 10M"│ │ fit      │  │ "Python at"│
    │ "40%↓"   │ │          │  │ "Scale..."│
    └────┬─────┘ └────┬─────┘  └────┬───────┘
         │             │            │
         └─────────────┼────────────┘
                       │
                       ▼
        ╔═════════════════════════════════╗
        ║  Output: Structured JSON        ║
        ║  (Used by downstream stages)    ║
        ╚═════════════════════════════════╝

Analysis Result Example:
{
  "top_job_requirements": [
    "3+ years Python",
    "AWS infrastructure",
    "Team leadership"
  ],
  "top_resume_evidence": [
    "5 years Python development",
    "Built AWS infrastructure at scale",
    "Led team of 8 engineers"
  ],
  "skill_matches": {
    "Python": "Python, Django, FastAPI",
    "AWS": "EC2, RDS, Lambda, CloudFormation"
  },
  "quantified_achievements": [
    "Led migration of 10M users",
    "Reduced API latency by 40%"
  ],
  "strongest_overlap": "5 years Python backend with AWS 
                       infrastructure at scale matches 
                       role requirements perfectly",
  "company_insight": "Company is aggressively scaling, and 
                     candidate has proven track record 
                     leading teams through growth",
  "subject_angles": [
    "Scaled Python Backend to 10M Users",
    "AWS Infrastructure Expert — Ready to Lead",
    "Proven 40% Performance Improvement Record"
  ]
}
```

---

## Generation Pipeline Comparison

### BEFORE: Simple Direct Generation
```
Resume Evidence (3 items)
    │
    ▼
Job Details
    │
    ▼
    LLM "write email"
    │
    ▼
Generic Email
    ├── "I am writing to apply..." ❌
    ├── "I believe I'm a good fit" ❌
    ├── "Python, AWS, leadership" (skills dump) ❌
    └── "Please find resume attached" ❌
```

### AFTER: Analysis-Informed Generation
```
Analysis Context (7 data points)
    │
    ├─ strongest_overlap
    ├─ quantified_achievements
    ├─ company_insight
    ├─ skill_matches
    ├─ top_job_requirements
    ├─ top_resume_evidence
    └─ subject_angles
    │
    ├─────────────────┬──────────────────┐
    │                 │                  │
    ▼                 ▼                  ▼
Resume Evidence   Job Details      Analysis Data
(5+ items, not 3)                 (Strategic context)
    │                 │                  │
    └─────────────────┼──────────────────┘
                      │
                      ▼
    LLM "write_mail(with analysis=...)"
                      │
    ┌─────────────────┼─────────────────────────┐
    │                 │                         │
    ▼                 ▼                         ▼
Enforce           Use Analysis      Block Generic
4-paragraph       Context to         Phrases
Structure:        personalize:       Actively:
│                 │                 │
├─Hook:          ├─Opening with    ├─NO "I am"
│ "Your            company          │  "writing"
│  scaling         insight           │
│  challenge"    ├─Strongest        ├─NO "I
│              │  overlap         │  believe I'm
├─Evidence:      │  statement      │  good fit"
│ "I built       ├─Quantified      │
│  10M user        achieve.       ├─NO "Please
│  systems"     │  from analysis  │  find resume"
│                │                 │
├─Fit:          ├─Company         ├─NO skill
│ "Your          │  personalized   │  dumps
│  growth"       │  CTA           │
│                │                 └─Result:
└─CTA:          └─Confident,       ZERO banned
  "Let's          specific,        phrases
   discuss"       human tone       ✓
                                   (vs many before)
    │
    ▼
High-Signal Email
├── Specific, relevant opening ✓
├── Quantified proof ✓
├── Company personalization ✓
├── Clear structure ✓
└── No generic phrases ✓
```

---

## Resume Data Flow

### BEFORE: Limited Access
```
Resume PDF
    │
    ▼
Extract text
    │
    ▼
Split into sections:
├─ Personal Info
├─ Skills
├─ Experience
└─ etc.
    │
    ▼
Create embeddings
    │
    ▼
query_resume(job_query, n_results=3)
    │
    ▼
Return 3 best matches ◄─── TOO NARROW
    │
    ▼
Used in email generation
```

### AFTER: Richer Context
```
Resume PDF
    │
    ▼
Extract text
    │
    ▼
Split into sections:
├─ Personal Info
├─ Skills
├─ Experience
├─ Projects
├─ Certifications
└─ etc.
    │
    ▼
Create embeddings
    │
    ▼
TWO ACCESS PATTERNS:
│
├─ Path 1: get_all_sections_text()
│           │
│           ▼
│           Full formatted resume
│           (for analysis stage)
│
└─ Path 2: query_resume(job_query, n_results=5)
            │
            ▼
            Return 5+ best matches ◄─── WIDER
            (for email generation)
            
            │
            ▼
            LLM can choose best 1-3
            from 5 candidates
            (better quality output)
```

---

## Quality Improvements at Each Stage

```
INPUT: Job description + Resume
       │
       ▼
STAGE 1: Analysis
│
├─ Extracts top requirements ✓
├─ Finds top resume evidence ✓
├─ Maps skills explicitly ✓
├─ Identifies quantified achievements ✓
├─ Creates company insight ✓
└─ Generates subject angles ✓
│
▼
STAGE 2A: Subject Generation
│
├─ Receives subject_angles ✓
├─ Creates benefit-driven subject ✓
├─ Specific to role + candidate ✓
└─ NOT generic template ✓
│
▼
STAGE 2B: Email Generation
│
├─ Uses analysis context ✓
├─ Wider resume window (5 vs 3) ✓
├─ Enforces structure (4 paragraphs) ✓
├─ Requires quantified evidence ✓
├─ Blocks banned phrases actively ✓
├─ Personalizes to company ✓
└─ Sounds human + confident ✓
│
▼
OUTPUT: High-signal, personalized,
        evidence-backed email
        
        Ready to send with minimal editing
        (vs high editing overhead before)
```

---

## Decision Tree: When to Use Analysis vs Direct Generation

```
                 Should we analyze?
                       │
        ┌──────────────┴──────────────┐
        │                             │
       YES                            NO
        │                             │
        │ (Use new pipeline)          │ (Keep old method)
        │                             │
        ├─ First-time user       ├─ User knows LLM will...
        │  wants best quality     │  ...regenerate anyway
        │                         │
        ├─ High-value target    ├─ Bulk generation
        │  (great company)       │  (100+ emails)
        │                        │
        ├─ Needs personalization ├─ Limited API budget
        │  at scale              │
        │                        │
        └─ Has time for quality └─ Generic emails OK
           (willing to wait
            6 seconds for
            better output)
        
        → Use: llm.analyze_fit() + llm.generate_subject_line()
           → Use: llm.write_mail(analysis=analysis)
        
        → Use: llm.extract_jobs() → direct llm.write_mail()
```

---

## Improvement Metrics

```
METRIC                    BEFORE    AFTER      IMPROVEMENT
────────────────────────────────────────────────────────
Subject Line Quality      3/10      9/10       +200%
Email Body Quality        5/10      9/10       +80%
Personalization Score     3/10      9/10       +200%
Quantified Evidence       2/10      9/10       +350%
Generic Phrase Count      5-7       0          -100%
Resume Evidence Used      3 items   5+ items   +67%
API Calls                 2         4          +100%
Time to Generate          3 sec     6 sec      +100%
Manual Editing Needed     High      Low        -60%
Confidence in Output      Low       High       +200%

(Metrics are illustrative based on expected improvements)
```

---

## Summary: What Changed?

```
┌─────────────────────┬──────────────┬──────────────┬──────────────┐
│ Component           │ Before       │ After        │ Key Benefit  │
├─────────────────────┼──────────────┼──────────────┼──────────────┤
│ Subject Gen         │ Template     │ LLM + angles │ Specific,    │
│                     │              │              │ benefit-     │
│                     │              │              │ driven       │
├─────────────────────┼──────────────┼──────────────┼──────────────┤
│ Email Gen           │ Single-pass  │ Analysis-    │ Strategic,   │
│                     │              │ informed     │ personalized │
├─────────────────────┼──────────────┼──────────────┼──────────────┤
│ Resume Window       │ 3 items      │ 5+ items     │ More choice, │
│                     │              │              │ better picks │
├─────────────────────┼──────────────┼──────────────┼──────────────┤
│ Skill Mapping       │ Implicit     │ Explicit     │ Forces clear │
│                     │              │ JSON         │ connection   │
├─────────────────────┼──────────────┼──────────────┼──────────────┤
│ Quantified Evidence │ Optional     │ Required     │ More          │
│                     │              │              │ credible      │
├─────────────────────┼──────────────┼──────────────┼──────────────┤
│ Generic Phrases     │ Vague guide  │ Explicit     │ Zero banned  │
│                     │              │ block list   │ phrases      │
├─────────────────────┼──────────────┼──────────────┼──────────────┤
│ Structure           │ Suggested    │ Enforced     │ Consistent,  │
│                     │              │              │ scannable    │
└─────────────────────┴──────────────┴──────────────┴──────────────┘
```
